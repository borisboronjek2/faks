#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

#define MSG_KEY 1234
#define NUM_PROC 4
#define NUM_PUSACI 3

typedef struct {
    long msg_type;          
    int sender;
    int lamport_clock;
    char type[10];          
    int s1;                 
    int s2;
} message_t;

typedef struct req_node {
    int sender;
    int clock;
    struct req_node* next;
} req_node;

typedef enum {IDLE, REQUESTING, IN_CRITICAL} State;

req_node* insert_sorted(req_node* head, int sender, int clock) {
    req_node* new_node = malloc(sizeof(req_node));
    new_node->sender = sender;
    new_node->clock = clock;
    new_node->next = NULL;

    if(!head || clock < head->clock || (clock==head->clock && sender < head->sender)) {
        new_node->next = head;
        return new_node;
    }

    req_node* curr = head;
    while(curr->next && (curr->next->clock < clock || (curr->next->clock==clock && curr->next->sender < sender))) {
        curr = curr->next;
    }
    new_node->next = curr->next;
    curr->next = new_node;
    return head;
}

req_node* remove_req(req_node* head, int sender) {
    req_node* curr = head;
    req_node* prev = NULL;
    while(curr) {
        if(curr->sender == sender) {
            if(prev) prev->next = curr->next;
            else head = curr->next;
            free(curr);
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    return head;
}

int is_first(req_node* head, int sender) {
    return head && head->sender == sender;
}

void send_msg(int qid, int sender, int dest, int lamport, const char* type, int s1, int s2) {
    message_t msg;
    msg.msg_type = dest + 1;
    msg.sender = sender;
    msg.lamport_clock = lamport;
    strcpy(msg.type, type);
    msg.s1 = s1;
    msg.s2 = s2;
    msgsnd(qid, &msg, sizeof(msg) - sizeof(long), 0);

    const char* sender_label = (sender==0) ? "T" : (char[5]){0};
    const char* dest_label = (dest==0) ? "T" : (char[5]){0};
    if(sender!=0) sprintf((char*)sender_label, "P%d", sender);
    if(dest!=0) sprintf((char*)dest_label, "P%d", dest);

    if (strcmp(type, "TABLE") == 0) {
        printf("[%s | Clock %d] Trgovac stavlja na stol sastojke %d i %d\n",
               sender_label, lamport, s1, s2);
    } else {
        printf("[%s | Clock %d] Poslano od %s do %s: %s\n",
               sender_label, lamport, sender_label, dest_label, type);
    }
}

void recv_msg(int qid, int pid, message_t* msg, int* lamport) {
    msgrcv(qid, msg, sizeof(message_t) - sizeof(long), pid + 1, 0);
    *lamport = (*lamport > msg->lamport_clock ? *lamport : msg->lamport_clock) + 1;

    const char* recv_label = (pid==0) ? "T" : (char[5]){0};
    const char* sender_label = (msg->sender==0) ? "T" : (char[5]){0};
    if(pid!=0) sprintf((char*)recv_label, "P%d", pid);
    if(msg->sender!=0) sprintf((char*)sender_label, "P%d", msg->sender);

    if (strcmp(msg->type, "TABLE") != 0) {
        printf("[%s | Clock %d] Primljeno od %s kod %s: %s\n",
               recv_label, *lamport, sender_label, recv_label, msg->type);
    }
}


void choose_two(int *s1, int *s2) {
    *s1 = rand()%3;
    do { *s2 = rand()%3; } while(*s2==*s1);
}

void trgovac_process(int qid, int pid) {
    srand(time(NULL) ^ getpid());

    int lamport = 1 + rand() % 100;
    req_node* queue = NULL;
    State state = IDLE;
    int table_s1=-1, table_s2=-1;
    int release_needed = 0;

    while(1) {
        if(state == IDLE){
            choose_two(&table_s1,&table_s2);
            for(int j=1;j<NUM_PROC;j++)
                send_msg(qid,pid,j,lamport,"TABLE",table_s1,table_s2);
            state = REQUESTING;  
            release_needed = 0;
        }

        message_t msg;
        recv_msg(qid,pid,&msg,&lamport);

        if(strcmp(msg.type,"REQUEST")==0){
            queue = insert_sorted(queue,msg.sender,msg.lamport_clock);
            send_msg(qid,pid,msg.sender,lamport,"REPLY",0,0);
        }
        else if(strcmp(msg.type,"RELEASE")==0){
            queue = remove_req(queue,msg.sender);
            release_needed++;
            if(release_needed>=1){
                state = IDLE; 
            }
        }
    }
}

void pusac_process(int qid, int pid) {
    srand(time(NULL) ^ getpid());

    int lamport = 1 + rand() % 100;
    req_node* queue = NULL;
    int replies_received = 0;
    State state = IDLE;
    int my_ingredient = pid - 1;
    int table_s1=-1, table_s2=-1;

    while(1) {
        message_t msg;
        recv_msg(qid,pid,&msg,&lamport);

        if(strcmp(msg.type,"TABLE")==0){
            table_s1 = msg.s1;
            table_s2 = msg.s2;
            if(my_ingredient!=table_s1 && my_ingredient!=table_s2){
                queue = insert_sorted(queue,pid,lamport);
                for(int target=0; target<NUM_PROC; target++)
                    if(target!=pid) send_msg(qid,pid,target,lamport,"REQUEST",0,0);
                state = REQUESTING;
                replies_received = 0;
            }
        } 
        else if(strcmp(msg.type,"REQUEST")==0){
            queue = insert_sorted(queue,msg.sender,msg.lamport_clock);
            send_msg(qid,pid,msg.sender,lamport,"REPLY",0,0);
        } 
        else if(strcmp(msg.type,"REPLY")==0){
            replies_received++;
        } 
        else if(strcmp(msg.type,"RELEASE")==0){
            queue = remove_req(queue,msg.sender);
        }

        if(state==REQUESTING && is_first(queue,pid) && replies_received==NUM_PROC-1){
            state = IN_CRITICAL;
            printf("Pušač %d ulazi u KO\n",my_ingredient);
            sleep(1);
            printf("Pušač %d puši cigaretu\n",my_ingredient);
            sleep(1);
            printf("Pušač %d izlazi iz KO\n",my_ingredient);
            for(int j=0;j<NUM_PROC;j++) 
                if(j!=pid) send_msg(qid,pid,j,lamport,"RELEASE",0,0);
            
            queue = remove_req(queue,pid);
            replies_received = 0;
            state = IDLE;
            table_s1 = table_s2 = -1;
            sleep(1);
        }
    }
}

int main() {
    int qid = msgget(MSG_KEY, IPC_CREAT | 0666);
    if(qid <0) { perror("msgget"); exit(1); }

    srand(time(NULL));

    for(int i=0;i<NUM_PROC;i++) {
        if(fork()==0) {
            if(i==0)
                trgovac_process(qid, i);
            else
                pusac_process(qid, i);
            exit(0);
        }
    }

    while(wait(NULL)>0);
    return 0;
}
