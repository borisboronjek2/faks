#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>

#define NUM_POSJETITELJA 12
#define MJESTA 4

typedef struct {
    int id;
    int pipe_to_vrtuljak[2];
    int pipe_from_vrtuljak[2];
} Posjetitelj;

void vrtuljak(Posjetitelj posjetitelji[]);
void posjetitelj(Posjetitelj p);
int max(int a, int b) { return (a > b) ? a : b; }

int main() {
    srand(time(NULL));
    Posjetitelj posjetitelji[NUM_POSJETITELJA];

    for (int i = 0; i < NUM_POSJETITELJA; i++) {
        posjetitelji[i].id = i + 1;
        pipe(posjetitelji[i].pipe_to_vrtuljak);
        pipe(posjetitelji[i].pipe_from_vrtuljak);
    }

    pid_t pid = fork();
    if (pid == 0) {
        vrtuljak(posjetitelji);
        exit(0);
    }

    for (int i = 0; i < NUM_POSJETITELJA; i++) {
        pid_t cpid = fork();
        if (cpid == 0) {
            posjetitelj(posjetitelji[i]);
            exit(0);
        }
    }

    for (int i = 0; i < NUM_POSJETITELJA + 1; i++)
        wait(NULL);

    return 0;
}

void posjetitelj(Posjetitelj p) {
    close(p.pipe_to_vrtuljak[0]);
    close(p.pipe_from_vrtuljak[1]);
    srand(time(NULL) ^ getpid());

    int clock = 1 + rand() % 100;

    char msg[64];
    char buffer[64];

    for (int i = 0; i < 2; i++) {
        int ms = 100 + rand() % 1900;
        usleep(ms * 1000);

        sprintf(msg, "Želim se voziti|%d", clock);
        printf("[P%d | clock=%d] šalje -> %s\n", p.id, clock, msg);
        write(p.pipe_to_vrtuljak[1], msg, strlen(msg) + 1);

        read(p.pipe_from_vrtuljak[0], buffer, sizeof(buffer));
        char tip[32]; int recv_time = 0;
        sscanf(buffer, "%[^|]|%d", tip, &recv_time);
        clock = max(clock, recv_time) + 1;

        printf("[P%d | clock=%d] primio <- %s\n", p.id, clock, tip);

        if (strcmp(tip, "Sjedi") == 0) {
            printf("[P%d | clock=%d] Sjeo posjetitelj\n", p.id, clock);

            read(p.pipe_from_vrtuljak[0], buffer, sizeof(buffer));
            sscanf(buffer, "%[^|]|%d", tip, &recv_time);
            clock = max(clock, recv_time) + 1;

            printf("[P%d | clock=%d] primio <- %s\n", p.id, clock, tip);
            if (strcmp(tip, "Ustani") == 0) {
                printf("[P%d | clock=%d] Sišao posjetitelj\n", p.id, clock);
            }
        }
    }

    sprintf(msg, "Posjetitelj %d završio|%d", p.id, clock);
    printf("[P%d | clock=%d] šalje -> %s\n", p.id, clock, msg);
    write(p.pipe_to_vrtuljak[1], msg, strlen(msg) + 1);
}

void vrtuljak(Posjetitelj posjetitelji[]) {
    for (int i = 0; i < NUM_POSJETITELJA; i++) {
        close(posjetitelji[i].pipe_to_vrtuljak[1]);
        close(posjetitelji[i].pipe_from_vrtuljak[0]);
    }
    srand(time(NULL) ^ getpid());

    int clock = 1 + rand() % 100;

    int aktivni = NUM_POSJETITELJA;
    char msg[64];
    int mjesta_zauzeta = 0;
    int reda[MJESTA];

    while (aktivni > 0) {
        for (int i = 0; i < NUM_POSJETITELJA; i++) {
            int n = read(posjetitelji[i].pipe_to_vrtuljak[0], msg, sizeof(msg));
            if (n > 0) {
                char tip[32];
                int recv_time = 0;
                sscanf(msg, "%[^|]|%d", tip, &recv_time);
                clock = max(clock, recv_time) + 1;

                if (strncmp(tip, "Želim se voziti", 15) == 0) {
                    printf("[V | clock=%d] primio <- %s od P%d\n", clock, tip, i+1);
                    reda[mjesta_zauzeta++] = i;
                    if (mjesta_zauzeta == MJESTA) {
                        for (int j = 0; j < MJESTA; j++) {
                            sprintf(msg, "Sjedi|%d", clock);
                            printf("[V | clock=%d] šalje -> %s P%d\n", clock, msg, reda[j]+1);
                            write(posjetitelji[reda[j]].pipe_from_vrtuljak[1], msg, strlen(msg) + 1);
                        }

                        printf("[V | clock=%d] Pokrenuo vrtuljak\n", clock);
                        int ms = 1000 + rand() % 2000;
                        usleep(ms * 1000);
                        printf("[V | clock=%d] Vrtuljak zaustavljen\n", clock);

                        for (int j = 0; j < MJESTA; j++) {
                            sprintf(msg, "Ustani|%d", clock);
                            printf("[V | clock=%d] šalje -> %s P%d\n", clock, msg, reda[j]+1);
                            write(posjetitelji[reda[j]].pipe_from_vrtuljak[1], msg, strlen(msg) + 1);
                        }
                        mjesta_zauzeta = 0;
                    }
                } 
                else if (strncmp(tip, "Posjetitelj", 11) == 0) {
                    printf("[V | clock=%d] primio <- %s\n", clock, tip);
                    aktivni--;
                }
            }
        }
    }
    printf("[V | clock=%d] Svi posjetitelji završili. Kraj simulacije.\n", clock);
}