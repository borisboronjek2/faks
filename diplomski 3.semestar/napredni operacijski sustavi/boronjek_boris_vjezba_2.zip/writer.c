/* 
    writer.c
*/
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                        } while (0)

int
main(int argc, char *argv[])
{
    int            ready;
    nfds_t         nfds;
    struct pollfd *pfds;

    if (argc < 2) {
        fprintf(stderr, "Usage: %s file...\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));

    nfds = argc - 1;
    pfds = calloc(nfds, sizeof(struct pollfd));
    if (pfds == NULL)
        errExit("malloc");

    /* Open each file on command line, and add it to 'pfds' array. */

    for (nfds_t j = 0; j < nfds; j++) {
        pfds[j].fd = open(argv[j + 1], O_WRONLY);
        if (pfds[j].fd == -1)
            errExit("open");

        printf("Opened \"%s\" on fd %d\n", argv[j + 1], pfds[j].fd);

        pfds[j].events = POLLOUT;
    }

    /* Keep calling poll() as long as at least one file descriptor is
        open. */

    while (1) {
        sleep(5);

        printf("About to poll()\n");
        ready = poll(pfds, nfds, 0);
        if (ready == -1)
            errExit("poll");

        if (ready == 0)
            continue;

        /* Collect all writable fds */
        int writable[nfds];
        int count = 0;

        for (nfds_t j = 0; j < nfds; j++) {
            if (pfds[j].revents & POLLOUT) {
                writable[count++] = j;
            }
        }

        if (count > 0) {
            int idx = writable[rand() % count];
            char c = 'A' + (rand() % 26);

            if (write(pfds[idx].fd, &c, 1) != 1)
                errExit("write");

            printf("Written '%c' to %s (fd=%d)\n",
                   c, argv[idx + 1], pfds[idx].fd);
        }
    }

    printf("All file descriptors closed; bye\n");
    exit(EXIT_SUCCESS);
}